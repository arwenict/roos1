window.addEvent('domready', function(){

		if (jj_am_parent_link_enabled == "0") {
			var jj_am_parent_link = document.getElementById("jj_accordion_menu").getElementsByTagName("A");
			for (var jj_am_parent_link_y=0; jj_am_parent_link_y<jj_am_parent_link.length; jj_am_parent_link_y++) {
				if (jj_am_parent_link[jj_am_parent_link_y].parentNode.parentNode.tagName == "H3") {
					jj_am_parent_link[jj_am_parent_link_y].href = "javascript:;";
				}
			}
		}

		function jj_am_h3_background_load() {
			var jj_am_h3_close = document.getElementById("jj_accordion_menu").getElementsByTagName("H3");
			for (var jj_am_h3_close_y=0; jj_am_h3_close_y<jj_am_h3_close.length; jj_am_h3_close_y++) {
					if (jj_am_h3_close[jj_am_h3_close_y].nextSibling.innerHTML == "" || jj_am_h3_close[jj_am_h3_close_y].nextSibling.innerHTML == " ") {
						jj_am_h3_close[jj_am_h3_close_y].className = "jj_am_toggler jj_am_not_parent";
					}
					if (jj_am_h3_close[jj_am_h3_close_y].nextSibling.innerHTML != "" && jj_am_h3_close[jj_am_h3_close_y].nextSibling.innerHTML != " ") {
						jj_am_h3_close[jj_am_h3_close_y].className = "jj_am_toggler jj_am_parent";
					}
			}
			if (this.nextSibling.innerHTML == "" || this.nextSibling.innerHTML == " ") {
				this.className = "jj_am_toggler jj_am_open jj_am_not_parent";
			}
			if (this.nextSibling.innerHTML != "" && this.nextSibling.innerHTML != " ") {
				this.className = "jj_am_toggler jj_am_open jj_am_parent";
			}
		}
		
		var jj_am_h3_background = document.getElementById("jj_accordion_menu").getElementsByTagName("H3");
		for (var jj_am_h3_background_y=0; jj_am_h3_background_y<jj_am_h3_background.length; jj_am_h3_background_y++) {
				jj_am_h3_background[jj_am_h3_background_y].onclick = jj_am_h3_background_load;
		}
		
		var jj_am_element = document.getElementById("jj_accordion_menu").getElementsByTagName("DIV");
		for (var jj_am_element_y=0; jj_am_element_y<jj_am_element.length; jj_am_element_y++) {
			if (jj_am_element[jj_am_element_y].className == "jj_accordion_menu_element") {
				if (jj_am_element[jj_am_element_y].innerHTML != "") {
					jj_am_element[jj_am_element_y].style.display = jj_accordion_menu_display;
				}
				if (jj_am_element[jj_am_element_y].innerHTML == " " || jj_am_element[jj_am_element_y].innerHTML == "") {
					jj_am_element[jj_am_element_y].previousSibling.className = "jj_am_toggler jj_am_not_parent";
				}
				if (jj_am_element[jj_am_element_y].innerHTML != " " && jj_am_element[jj_am_element_y].innerHTML != "") {
					jj_am_element[jj_am_element_y].previousSibling.className = "jj_am_toggler jj_am_parent";
				}
			}
		}
		
		var jj_am_current_level = 0;
		
		var jj_am_h3_current = document.getElementById("jj_accordion_menu").getElementsByTagName("H3");
		for (var jj_am_h3_current_y=0; jj_am_h3_current_y<jj_am_h3_current.length; jj_am_h3_current_y++) {
			if (jj_am_h3_current[jj_am_h3_current_y].id == "current") {
				jj_am_current_level = jj_am_h3_current_y;
			}
		}
		
		var jj_am_li_current = document.getElementById("jj_accordion_menu").getElementsByTagName("LI");
		for (var jj_am_li_current_y=0; jj_am_li_current_y<jj_am_li_current.length; jj_am_li_current_y++) {
			if (jj_am_li_current[jj_am_li_current_y].id == "current") {
				
				if (jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.className == "jj_accordion_menu_element") {
					jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.id = "jj_am_parent_div_current";
				}
				
				else if (jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.parentNode.className == "jj_accordion_menu_element") {
					jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.parentNode.id = "jj_am_parent_div_current";
				}
				
				else if (jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.parentNode.parentNode.className == "jj_accordion_menu_element") {
					jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.parentNode.parentNode.id = "jj_am_parent_div_current";
				}
				
				else if (jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.parentNode.parentNode.parentNode.className == "jj_accordion_menu_element") {
					jj_am_li_current[jj_am_li_current_y].parentNode.parentNode.parentNode.parentNode.parentNode.id = "jj_am_parent_div_current";
				}
				
				var jj_am_div_current = document.getElementById("jj_accordion_menu").getElementsByTagName("DIV");
				for (var jj_am_div_current_y=0; jj_am_div_current_y<jj_am_div_current.length; jj_am_div_current_y++) {
					if (jj_am_div_current[jj_am_div_current_y].id == "jj_am_parent_div_current") {
						jj_am_current_level = jj_am_div_current_y - 1;
					}
				}
				
			}
		}


         jj_am_openElement = jj_am_current_level;

         var jj_accordion_menu = new Accordion($('jj_accordion_menu'), 'h3.jj_am_toggler', 'div.jj_accordion_menu_element', {
                opacity: true,
				allowMultipleOpen: true,
				display: jj_am_h3_first,
				alwaysHide: true
         });




		 
		var jj_am_h3_first = document.getElementById("jj_accordion_menu").getElementsByTagName("H3");
		for (var jj_am_h3_first_y=0; jj_am_h3_first_y<jj_am_h3_first.length; jj_am_h3_first_y++) {
			if (jj_am_h3_first_y == jj_am_current_level) {
				if (jj_am_h3_first[jj_am_h3_first_y].nextSibling.innerHTML == "" || jj_am_h3_first[jj_am_h3_first_y].nextSibling.innerHTML == " ") {
					jj_am_h3_first[jj_am_h3_first_y].className = "jj_am_toggler jj_am_open jj_am_not_parent";
				}
				if (jj_am_h3_first[jj_am_h3_first_y].nextSibling.innerHTML != "" && jj_am_h3_first[jj_am_h3_first_y].nextSibling.innerHTML != " ") {
					jj_am_h3_first[jj_am_h3_first_y].className = "jj_am_toggler jj_am_open  jj_am_parent";
				}
			}
		}
		 

 });

