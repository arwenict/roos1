<?php
/**
* @package   JJ Slider
* @copyright Copyright (C) 2005 - 2011 Open Source Matters. All rights reserved.
* @license   http://www.gnu.org/licenses/lgpl.html GNU/LGPL, see LICENSE.php
* Contact to : web@eucso.info, euCSO.info
**/
defined('_JEXEC') or die('Restricted access'); 

class modJJSliderHelper
{
    
}
?>