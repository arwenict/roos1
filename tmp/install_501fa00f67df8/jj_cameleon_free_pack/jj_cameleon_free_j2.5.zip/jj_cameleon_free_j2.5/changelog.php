<?php
/**
* @package   jj_cameleon Template
* @file      changelog.php
* @version   1.0.0 Feb 2012
* @author    JJdesign http://www.eucso.info
* @copyright Copyright (C) 2005 - 2011 euCSO
* @license   euCSO Proprietary Use License (http://www.eucso.info/license.html)
*/

// no direct access
die('Restricted access');

?>

Changelog
------------


1.0.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note